
# Laravel Docker Setup

This repository provides a ready-to-use Docker-based environment for Laravel development with support for multiple environments.

## Included Services

- **Laravel** (PHP 8.2)
- **MySQL 8**
- **Redis**
- **Nginx**
- **phpMyAdmin**
- **Multi-environment support** (`.env.dev`, `.env.staging`, `.env.prod`)

---

## 🐳 Getting Started

### 1. Install Docker

#### For **Windows**:

1. Download Docker Desktop: [https://www.docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop)
2. Run the installer and follow the instructions.
3. Restart your computer if prompted.
4. Launch Docker Desktop and make sure it’s running (check system tray).
5. Enable **WSL2 backend** if prompted.

#### For **Ubuntu**:

```bash
# Update existing packages
sudo apt update

# Install dependencies
sudo apt install apt-transport-https ca-certificates curl software-properties-common lsb-release gnupg -y

# Add Docker’s official GPG key
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/trusted.gpg.d/docker.gpg

# Add Docker’s repository
echo "deb [arch=$(dpkg --print-architecture)] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Install Docker Engine
sudo apt update
sudo apt install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin -y

# Optional: Add your user to the docker group
sudo usermod -aG docker $USER
newgrp docker
```

> Verify installation:
```bash
docker --version
docker run hello-world
```

---

### 2. Clone This Repository

```bash
git clone https://your-repo-url
cd laravel-docker-setup
```

---

### 3. Start Docker Environment

```bash
docker-compose up --build
```

> This builds and starts all services (Laravel, MySQL, Redis, Nginx, phpMyAdmin).

---

### 4. Access Services

- **Laravel App**: [http://localhost:8080](http://localhost:8080)
- **phpMyAdmin**: [http://localhost:8081](http://localhost:8081)
  - **User**: `root`
  - **Password**: `root`

---

### 5. Multi-Environment Support

This setup supports multiple environments:

- `.env.dev` – for development
- `.env.staging` – for staging
- `.env.prod` – for production

You can copy the relevant file as `.env` based on your environment:

```bash
cp .env.dev .env
```

---

## ✅ Tips

- Run Artisan commands:
  ```bash
  docker exec -it app php artisan migrate
  ```
- Composer install:
  ```bash
  docker exec -it app composer install
  ```
- Laravel logs:
  ```bash
  docker exec -it app tail -f storage/logs/laravel.log
  ```

---

## 🧹 Stop Docker

```bash
docker-compose down
```

---

## 🛠 Troubleshooting

- Make sure ports `8080` and `8081` are not in use.
- If `permission denied` errors occur on Linux, ensure your user is in the `docker` group.

---

## 📄 License

MIT License
