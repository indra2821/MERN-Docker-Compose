<!DOCTYPE html>
<html>
<head>
    <title>Laravel Test App</title>
</head>
<body>
    <h1>It works!</h1>
</body>
</html>